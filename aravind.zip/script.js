(function(){
 var app = angular.module('sam',[]);
 app.controller('samcontroller',function(){
	 this.product=s;
	 console.log("script execute");
});

var s=
[{
	name: 'G.ARAVINDKANNAN',
	price: 500,
	description: '* * * * ',
},
{
	name: 'Computer Science and Engineering',
	price: 250,
	description: '* * * * ',
},
{
	name: 'Karpagam University',
		price: 100,
	description: '* * * * ',
}];
})();